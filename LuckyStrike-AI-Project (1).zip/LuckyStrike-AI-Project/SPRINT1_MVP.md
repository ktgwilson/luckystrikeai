# 🏁 Sprint 1 — MVP Foundation

## Goal
Build a playable MVP with daily scratch card loop, wallet, basic RNG, and analytics.

---

## 🚀 Sprint Backlog

### 🎨 UX/UI & Frontend
- Wireframe scratch card screen, wallet, and win animation flow
- Implement mobile scratch interaction (React Native)
- Simple home screen with ticket count, wallet, and "Scratch Now" CTA
- Basic win/lose/reward popup (Lottie animation stub)

### 🧩 Core Game Logic
- RNG engine: server-seeded or Chainlink VRF test integration
- Prize table: 3 tiers (common, rare, jackpot)
- Burn ticket after play, update wallet on win

### 🏦 Wallet & Tickets
- User wallet data model (tokens, coins, tickets)
- Daily free ticket logic (one per 24h, reset timer)
- Buy ticket stub (in-app purchase not required for MVP)

### 📈 Analytics & Push
- Integrate Firebase Analytics basic events (scratch, win, fail, session)
- Set up OneSignal for daily notification (MVP: test push)

### 🛡️ Legal & Compliance
- Age gate modal (DOB picker, 18+ check)
- Show ToS and Privacy popup on first launch

### 🧪 QA & Testing
- Internal alpha test: core loop, wallet updates, win/lose logic
- Crash/error reporting (Firebase Crashlytics or equivalent)

---

## 🏆 Definition of Done

- User can open the app, get a free scratch, scratch to reveal, see if they win, and wallet updates.
- Analytics/Crashlytics confirm events fire.
- Age gate and ToS shown first time.
- All flows tested on at least 2 devices.
