# API Stubs

This folder is for API endpoints, contracts, and integration tests.
Add your OpenAPI/Swagger files and implementation here.
