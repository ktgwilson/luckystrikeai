# Sample Mod

This is a placeholder for a user-generated or partner mod/plugin.
Add code, config, or documentation for mods here.
